@echo off
rem Vulkan Typing Studio - modern Windows launcher (Windows 8.1 / 10 / 11)
rem Opens the standalone app in your default web browser. No install, no network.
setlocal
set "APP=%~dp0Vulkan-Typing-Studio-Standalone.html"
if not exist "%APP%" (
  echo Cannot find Vulkan-Typing-Studio-Standalone.html next to this script.
  pause
  exit /b 1
)
start "" "%APP%"
exit /b 0
