#!/usr/bin/env sh
# Vulkan Typing Studio - Linux launcher
# Opens the standalone app in your default web browser. No install, no network.
set -e
APP="$(dirname "$0")/Vulkan-Typing-Studio-Standalone.html"
if [ ! -f "$APP" ]; then
  echo "Cannot find Vulkan-Typing-Studio-Standalone.html next to this script." >&2
  exit 1
fi
xdg-open "$APP" >/dev/null 2>&1 || echo "Could not open a browser automatically. Open this file manually: $APP"
