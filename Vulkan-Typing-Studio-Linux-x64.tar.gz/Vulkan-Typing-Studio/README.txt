VULKAN TYPING STUDIO — PORTABLE PACKAGE
=======================================
Version: 0.7.0 (V7)

A single-file, offline-first typing app for English and Hindi.
No installation, no account, no telemetry, and no network access.

HOW TO RUN
----------
1. Extract this folder anywhere you like (for example your Desktop or Documents).
2. Run the launcher for your platform:
     Windows : double-click  Start.bat
     Linux   : ./start.sh            (first time: chmod +x start.sh)
     macOS   : double-click  start.command   (first time: right-click > Open)
   Or simply double-click:
     Vulkan-Typing-Studio-Standalone.html
   It opens in your default web browser.

WHAT'S INSIDE
-------------
Vulkan-Typing-Studio-Standalone.html   The entire application (one file).
Start.bat / start.sh / start.command   One-click launchers.
README.txt                             This file.
LICENSE                                Apache License 2.0.

REQUIREMENTS
------------
Any modern, up-to-date browser: Microsoft Edge, Google Chrome,
Mozilla Firefox, Apple Safari, or Brave.
- Windows 8.1 or later
- Linux (any current distribution that ships a browser)
- macOS 11 (Big Sur) or later, on Apple Silicon or Intel

This package is NOT for Windows 7. For Windows 7, download the separate
"Vulkan-Typing-Studio-Windows7-Portable.zip" release asset instead.

FONTS
-----
Font binaries are not bundled because of their licenses. Install properly
licensed copies of the requested fonts for full coverage:
  Kruti Dev 010, Mangal, Nirmala UI, Shruti, Chanakya, Poor Richard,
  Arial, Georgia.
If a font is unavailable, the app falls back to available system fonts.

PRIVACY
-------
Everything runs locally inside your browser. Nothing is uploaded or phoned home.

Learn more: https://github.com/anacondy/Vulkan-Typing-Studio
