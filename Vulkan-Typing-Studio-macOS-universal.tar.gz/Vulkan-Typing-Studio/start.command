#!/usr/bin/env sh
# Vulkan Typing Studio - macOS launcher
# Opens the standalone app in your default web browser. No install, no network.
APP="$(dirname "$0")/Vulkan-Typing-Studio-Standalone.html"
if [ ! -f "$APP" ]; then
  echo "Cannot find Vulkan-Typing-Studio-Standalone.html next to this script." >&2
  exit 1
fi
open "$APP"
